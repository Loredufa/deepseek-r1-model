
import argparse
from transformers import AutoModelForCausalLM, AutoTokenizer

def main():
    parser = argparse.ArgumentParser(description="Generar texto con el modelo DeepSeek.")
    parser.add_argument("--input_text", type=str, required=True, help="Texto de entrada para el modelo.")
    args = parser.parse_args()
    model_name = "neuralmagic/DeepSeek-R1-Distill-Qwen-7B-quantized.w8a8"
                    
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForCausalLM.from_pretrained(model_name)
    except Exception as e:
        print(f"Error al cargar el modelo: {e}")                                                   
        exit(1)
                                                        
    inputs = tokenizer(args.input_text, return_tensors="pt")
    outputs = model.generate(**inputs)
    output_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
    print("Texto generado:", output_text)
                                                                            
if __name__ == "__main__":
    main()
